var indexSectionsWithContent =
{
  0: "_abcdefghilmnopqrstuvw",
  1: "cgimosu",
  2: "d",
  3: "m",
  4: "_abcdefghilmoprstuvw",
  5: "_abcdefghilmnopqrstuw",
  6: "cem",
  7: "abcdegilmnpqrstuw",
  8: "acdeflmnoprstv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Properties"
};

